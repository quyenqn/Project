package asm02;

public class Account {

    private String accountNumber;
    private double balance;

    public Account(String accountNumber, double balance){
        this.balance = balance;
        this.accountNumber = accountNumber;
}

    public Account() {
    }

    public String getAccountNumber(){
        return accountNumber;
    }
    public void setAccountNumber(String accountNumber){
        this.accountNumber = accountNumber;
    }
    public double getBalance(){
        return balance;
    }
    public void setBalance(double balance){
        this.balance = balance;
        }

    public boolean isPremium(){
        if(balance >= 10000000){
            return true;
        }
           return false;
    }
//
//    @Override
//     public String toString() {
//            return accountNumber + " " + "|" + "         " + balance;
//    }
//


}

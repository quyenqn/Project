package asm02;

import java.util.ArrayList;
import java.util.Scanner;

public class Asm02 {

    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            double d = Double.parseDouble(strNum);

        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;

    }

    // them khach hang
    private static  Bank bank = new Bank();

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int luachon = 0;

        do {
                System.out.println("+-----------+--------------------------------+-----------+");
                System.out.println("| NGAN HANG SO | FX17743@V1.0.0                          |");
                System.out.println("+-----------+--------------------------------+-----------+");
                System.out.println("1. Them khach hang ");
                System.out.println("2. Them tai khoan cho khach hang ");
                System.out.println("3. Hien thi danh sach khach hang ");
                System.out.println("4. Tim theo CCCD ");
                System.out.println("5. Tim theo ten khach hang ");
                System.out.println("0. Thoat ");
                System.out.println("+-----------+--------------------------------+-----------+");
                System.out.println("Chuc nang: ");
                luachon = sc.nextInt();
                sc.nextLine();
                if (luachon == 1) {
                    System.out.println("nhap ten khach hang: ");
                    String name = sc.nextLine();

                    System.out.println("nhap so CCCD: ");
                    String customerId = sc.nextLine();
                    if (customerId.length() == 12 && isNumeric(customerId)){
                        Customer cus = new Customer(name,customerId);
                        bank.addCustomer(cus);
                    }else {
                        do {
                            System.out.println("nhap lai CCCD: ");
                            customerId = sc.nextLine();
                        } while (!(customerId.length() == 12 && isNumeric(customerId)));
                    }

                } else if (luachon == 2) {
                    String customerId = "";
                    System.out.println("nhap CCCD khach hang: ");
                    customerId = sc.nextLine();

                    while (!bank.isCustomerExisted(customerId)){
                        System.out.println("CCCD khong ton tai, nhap lai CCCD khach hang: ");
                        customerId = sc.nextLine();
                    }
                            System.out.println("nhap ma stk gom 6 so: ");
                            String accountNumber = sc.next();
                            while (!(accountNumber.length() == 6 && isNumeric(accountNumber))) {
                                System.out.println("nhap lai ma stk gom 6 so: ");
                                accountNumber = sc.next();
                            }
                                System.out.println("nhap so du: ");
                                double balance = sc.nextInt();
                                while (balance < 50000) {
                                    System.out.println("nhap lai so du: ");
                                    balance = sc.nextInt();
                                }
                                    Account acc = new Account(accountNumber,balance);
                                    bank.addAccount(customerId,acc);

                } else if (luachon == 3 ) {
                    for (Customer cus: bank.getCustomers()
                         ) {
                        cus.displayInformation();
                    }
                    
                } else if (luachon == 4) {
                    System.out.println("nhap so CCCD can tim: ");
                    String customerId = sc.nextLine();
                    System.out.println("ket qua tim kiem: ");
                    bank.findCustomer(customerId);
                    
                } else if (luachon == 5) {
                    System.out.println("nhap ten can tim: ");
                    String name = sc.nextLine();
                    System.out.println("ket qua tim kiem:");
                    bank.findCustomerofname(name);
                }


        } while (luachon != 0);

    }




}

package asm02;


import asm03.LoansAccount;
import asm03.SavingsAccount;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;
public class Customer extends User {
    private ArrayList<Account> accounts = new ArrayList<>();

    public Customer(String name, String customerId) {
        super(name, customerId);
    }
    public Customer(String customerId) {
        super(customerId);
    }
    public Customer(String customerId, ArrayList<Account> accounts) {
        super(customerId);
        this.accounts = accounts;
    }

    public ArrayList<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(ArrayList<Account> accounts) {
        this.accounts = accounts;
    }

    public boolean isPremium(){
        for (Account account: accounts
             ) {
            if (account.isPremium()){
                return true;
            }
        }
        return false;
    }

    public void addAccount(Account newAccount){
        for (Account acc : accounts
            )  {
            if (newAccount.getAccountNumber().equals(acc.getAccountNumber())){
                System.out.println("so tk da ton tai");
                return;
            }

        }
        accounts.add(newAccount);
    }

    public double getBalance() {
        double balance = 0;
        for (Account acc : accounts
             ) {
        balance += acc.getBalance();
        }
        return balance ;
    }

//    public void displayInformation() {
//
//        Locale localeEN = new Locale("en", "EN");
//        NumberFormat en = NumberFormat.getInstance(localeEN);
//        int stt = 1;
//        if (isPremium()){
//            System.out.println(getCustomerId() + "|" + getName() + "|" + " Premium " + "|" + en.format(getBalance()));
//            for (Account acc : accounts
//                 ) {
//                    double ba = acc.getBalance();
//                System.out.println(stt++  +"    " + acc.getAccountNumber()  +  "                " +   +en.format(ba));
//            }
//
//        } else {
//            System.out.println(getCustomerId() + "|" + getName() + "|" + " Normal  " + "|" + en.format(getBalance()));
//            for (Account acc : accounts
//            ) {
//                double ba = acc.getBalance();
//                System.out.println(stt++  +"    " + acc.getAccountNumber()  + "              "  + en.format(ba));
//            }
//
//        }
//
//    }


    public void displayInformation() {
        Locale localeEN = new Locale("en", "EN");
        NumberFormat en = NumberFormat.getInstance(localeEN);
        int stt = 1;
        String type = "";
        if (isPremium()) {
            type = "Premium";
        } else {
            type = "Normal";
        }
        System.out.println(getCustomerId() + "|" + getName() + "|" + type + "|" + en.format(getBalance()));

        for (Account acc : accounts) {
            if (acc instanceof SavingsAccount) {
                SavingsAccount sa = (SavingsAccount) acc;
                System.out.println(stt + " | " + sa.toString());
            } else if (acc instanceof LoansAccount) {
                LoansAccount la = (LoansAccount) acc;
                System.out.println(stt + " | " + la.toString());
            }
            stt++;
        }
    }

}

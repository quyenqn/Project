package asm02;

import java.util.ArrayList;
import java.util.UUID;

public class Bank {
    private String id;
    private ArrayList<Customer> customers;

    public Bank() {
        this.id = String.valueOf(UUID.randomUUID());
        this.customers = new ArrayList<Customer>();
    }

    public Bank(String id, ArrayList<Customer> customers) {
        this.id = id;
        this.customers = customers;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ArrayList<Customer> getCustomers() {
        return customers;
    }

    public void setCustomers(ArrayList<Customer> customers) {
        this.customers = customers;
    }

    public void addCustomer(Customer newCustomer){
        for (Customer cus :  customers
             ) {
            if (newCustomer.getCustomerId().equals(cus.getCustomerId())){
                return;
            }

        }
        customers.add(newCustomer);
    }

    public void addAccount(String customerId, Account newAccount){
        if(!isCustomerExisted(customerId)) return;
        for (Customer cus : customers ) {
            if (customerId.equals(cus.getCustomerId())) {
                for (Account ac: cus.getAccounts()
                     ) {
                    if (ac.getAccountNumber().equals(newAccount.getAccountNumber())){
                        System.err.println("tai khoan da ton tai");
                        return;
                    }
                }
                cus.addAccount(newAccount);
                return;
            }
        }

    }

    public boolean isCustomerExisted(String customerId){
        for (Customer cus :  customers
        ) {
            if (customerId.equals(cus.getCustomerId())) {
                return true;
            }

        }
        return  false;
    }

    public void findCustomer(String customerId){
        for (Customer cus : customers) {
            if(cus.getCustomerId().equals(customerId)) {
                cus.displayInformation();
            }else {
                System.out.println("khong tim thay:");
            }
        }
        
    }

    public void findCustomerofname(String name){
        for (Customer cus : customers) {
            if(cus.getName().indexOf(name)>=0) {
                cus.displayInformation();
            } else {
                System.out.println("khong tim thay:");
            }
        }

    }

    public boolean checkAccountExisted(String customerId, String account) {
        for (Customer cus : customers) {
            if (customerId.equals(cus.getCustomerId())) {
                for (Account ac : cus.getAccounts()) {
                    if (ac.getAccountNumber().equals(account)) {
                        return true; //tai khoan da ton tai, khong the them moi.
                    }
                }
            }
        }
        return false; //tai khoan chua ton tai, co the them moi.
    }

}

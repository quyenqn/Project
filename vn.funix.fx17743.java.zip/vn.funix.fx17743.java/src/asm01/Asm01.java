package asm01;

import java.util.Random;
import java.util.Scanner;

public class Asm01 {
    public static String nhap(int num) {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxy1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < num) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;

    }

    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            double d = Double.parseDouble(strNum);

        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    public static String kiemTraNoiSinh(String s) {
        String tinh = s.substring(0, 3);
        switch (tinh) {
            case "001": {
                System.out.println("Nơi sinh : Ha Noi");
                break;
            }

            case "002": {
                System.out.println("Nơi sinh : Ha Giang");
                break;
            }
            case "004": {
                System.out.println("Nơi sinh : Cao Bằng");
                break;
            }
            case "006": {
                System.out.println("Nơi sinh : Bắc Kạn");
                break;
            }
            case "008": {
                System.out.println("Nơi sinh : Tuyên Quang");
                break;
            }
            case "010": {
                System.out.println("Nơi sinh : Lào Cai");
                break;
            }
            case "011": {
                System.out.println("Nơi sinh : Điện Biên");
                break;
            }
            case "012": {
                System.out.println("Nơi sinh : Lai Châu");
                break;
            }
            case "014": {
                System.out.println("Nơi sinh : Sơn La");
                break;
            }
            case "015": {
                System.out.println("Nơi sinh : Yên Bái");
                break;
            }
            case "017": {
                System.out.println("Nơi sinh : Hòa Bình");
                break;
            }
            case "019": {
                System.out.println("Nơi sinh : Thái Nguyên");
                break;
            }
            case "020": {
                System.out.println("Nơi sinh : Lạng Sơn");
                break;
            }
            case "022": {
                System.out.println("Nơi sinh : Quảng Ninh");
                break;
            }
            case "024": {
                System.out.println("Nơi sinh : Bắc Giang");
                break;
            }
            case "025": {
                System.out.println("Nơi sinh : Phú Thọ");
                break;
            }
            case "026": {
                System.out.println("Nơi sinh : Vĩnh Phúc");
                break;
            }
            case "027": {
                System.out.println("Nơi sinh : Bắc Ninh");
                break;
            }
            case "030": {
                System.out.println("Nơi sinh : Hải Dương");
                break;
            }
            case "031": {
                System.out.println("Nơi sinh : Hải Phòng");
                break;
            }
            case "033": {
                System.out.println("Nơi sinh : Hưng Yên");
                break;
            }
            case "034": {
                System.out.println("Nơi sinh : Thái Bình");
                break;
            }
            case "035": {
                System.out.println("Nơi sinh : Hà Nam");
                break;
            }
            case "036": {
                System.out.println("Nơi sinh : Nam Định");
                break;
            }
            case "037": {
                System.out.println("Nơi sinh : Ninh Bình");
                break;
            }
            case "038": {
                System.out.println("Nơi sinh : Thanh Hóa");
                break;
            }
            case "040": {
                System.out.println("Nơi sinh : Nghệ An");
                break;
            }
            case "042": {
                System.out.println("Nơi sinh : Hà Tĩnh");
                break;
            }
            case "044": {
                System.out.println("Nơi sinh : Quảng Bình");
                break;
            }
            case "045": {
                System.out.println("Nơi sinh : Quảng Trị");
                break;
            }
            case "046": {
                System.out.println("Nơi sinh : Thừa Thiên Huế");
                break;
            }
            case "048": {
                System.out.println("Nơi sinh : Đà Nẵng");
                break;
            }
            case "049": {
                System.out.println("Nơi sinh : Quảng Nam");
                break;
            }
            case "051": {
                System.out.println("Nơi sinh : Quảng Ngãi");
                break;
            }
            case "052": {
                System.out.println("Nơi sinh : Bình Định");
                break;
            }
            case "054": {
                System.out.println("Nơi sinh : Phú Yên");
                break;
            }
            case "056": {
                System.out.println("Nơi sinh : Khánh Hòa");
                break;
            }
            case "058": {
                System.out.println("Nơi sinh : Ninh Thuận");
                break;
            }
            case "060": {
                System.out.println("Nơi sinh : Bình Thuận");
                break;
            }
            case "062": {
                System.out.println("Nơi sinh : Kon Tum");
                break;
            }
            case "064": {
                System.out.println("Nơi sinh : Gia Lai");
                break;
            }
            case "066": {
                System.out.println("Nơi sinh : Đắk Lắk");
                break;
            }
            case "076": {
                System.out.println("Nơi sinh : Đắk Nông");
                break;
            }
            case "068": {
                System.out.println("Nơi sinh : Lâm Đồng");
                break;
            }
            case "070": {
                System.out.println("Nơi sinh : Bình Phước");
                break;
            }
            case "072": {
                System.out.println("Nơi sinh : Tây Ninh");
                break;
            }
            case "074": {
                System.out.println("Nơi sinh : Bình Dương");
                break;
            }
            case "075": {
                System.out.println("Nơi sinh : Đồng Nai");
                break;
            }
            case "077": {
                System.out.println("Nơi sinh : Bà Rịa - Vũng Tàu");
                break;
            }
            case "079": {
                System.out.println("Nơi sinh : Hồ Chí Minh");
                break;
            }
            case "080": {
                System.out.println("Nơi sinh : Long An");
                break;
            }
            case "082": {
                System.out.println("Nơi sinh : Tiền Giang");
                break;
            }
            case "083": {
                System.out.println("Nơi sinh : Bến Tre");
                break;
            }
            case "084": {
                System.out.println("Nơi sinh : Trà Vinh");
                break;
            }
            case "086": {
                System.out.println("Nơi sinh : Vĩnh Long");
                break;
            }
            case "087": {
                System.out.println("Nơi sinh : Đồng Tháp");
                break;
            }
            case "089": {
                System.out.println("Nơi sinh : An Giang");
                break;
            }
            case "091": {
                System.out.println("Nơi sinh : Kiên Giang");
                break;
            }
            case "092": {
                System.out.println("Nơi sinh : Cần Thơ");
                break;
            }
            case "093": {
                System.out.println("Nơi sinh : Hậu Giang");
                break;
            }
            case "094": {
                System.out.println("Nơi sinh : Sóc Trăng");
                break;
            }
            case "095": {
                System.out.println("Nơi sinh : Bạc Liêu");
                break;
            }
            case "096": {
                System.out.println("Nơi sinh : Cà Mau");
                break;
            }


            default:

                System.out.println("khong co tinh phu hop: ");
        }
        return tinh;
    }


    public static String kiemTraGioiTinh(String s) {
        String tuoi = s.substring(4, 6);
        String gioitinh = s.substring(3, 4);
        switch (gioitinh) {
            case "0": {
                System.out.println("gioi tinh,tuoi: nam" + "| 19" + tuoi );
                break;
            }

            case "1": {
                System.out.println("gioi tinh,tuoi : nu" + "| 19" + tuoi);
                break;
            }
            case "2": {
                System.out.println("gioi tinh,tuoi: nam" + "| 20" + tuoi );
                break;
            }

            case "3": {
                System.out.println("gioi tinh,tuoi : nu" + "| 20" + tuoi);
                break;
            }
            case "4": {
                System.out.println("gioi tinh,tuoi: nam" + "| 21" + tuoi );
                break;
            }

            case "5": {
                System.out.println("gioi tinh,tuoi : nu" + "| 21" + tuoi);
                break;
            }
            case "6": {
                System.out.println("gioi tinh,tuoi: nam" + "| 22" + tuoi );
                break;
            }

            case "7": {
                System.out.println("gioi tinh,tuoi : nu" + "| 22" + tuoi);
                break;
            }
            case "8": {
                System.out.println("gioi tinh,tuoi: nam" + "| 23" + tuoi );
                break;
            }

            case "9": {
                System.out.println("gioi tinh,tuoi : nu" + "| 23" + tuoi);
                break;
            }


            default:

                System.out.println("gioi tinh,tuoi khong phu hop: ");
        }
        return gioitinh;
    }


    public static String kiemTraSoNgauNhien(String s) {
        String songaunhien = s.substring(6);
        System.out.println("So ngau nhien: " + songaunhien);
        return songaunhien;

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int luachon = 0;
        System.out.println("+-----------+--------------------------------+-----------+");
        System.out.println("| NGAN HANG SO | FX17743@V1.0.0                          |");
        System.out.println("+-----------+--------------------------------+-----------+");
        System.out.println("| 1. Nhap CCCD                                           |");
        System.out.println("| 0. Thoat                                               |");
        System.out.println("+-----------+--------------------------------+-----------+");
        System.out.println("vui long chọn: 1.Nhap CCCD, 0.Thoát");
        do {
            luachon = sc.nextInt();
            if (luachon == 1) {

                String maxacthuc = nhap(6);

                String ma = "";
                do {
                    System.out.println("nhap ma xac thuc: " + maxacthuc);
                    ma = sc.next();
                    if (maxacthuc.equals(ma)) {
                        System.out.println("nhap so CCCD: ");
                        String CCCD = sc.next();
                        if (CCCD.length() == 12 && isNumeric(CCCD)) {
                            System.out.println("| 1. Kiem tra noi sinh ");
                            System.out.println("| 2. Kiem tra tuoi, gioi tinh ");
                            System.out.println("| 3. Kiem tra so ngau nhien ");
                            System.out.println("| 0. Thoat ");
                            System.out.println("chuc nang: ");
                            int kiemtra = 0;
                            kiemtra = sc.nextInt();
                            do {
                                if (kiemtra == 0){
                                    return;
                                }else

                                if(kiemtra == 1){

                                    kiemTraNoiSinh(CCCD);
                                    System.out.println("| 1. Kiem tra noi sinh ");
                                    System.out.println("| 2. Kiem tra tuoi, gioi tinh ");
                                    System.out.println("| 3. Kiem tra so ngau nhien ");
                                    System.out.println("| 0. Thoat ");
                                    System.out.println("chuc nang: ");
                                    kiemtra = sc.nextInt();
                                }else

                                if (kiemtra == 2) {

                                    kiemTraGioiTinh(CCCD);
                                    System.out.println("| 1. Kiem tra noi sinh ");
                                    System.out.println("| 2. Kiem tra tuoi, gioi tinh ");
                                    System.out.println("| 3. Kiem tra so ngau nhien ");
                                    System.out.println("| 0. Thoat ");
                                    System.out.println("chuc nang: ");
                                    kiemtra = sc.nextInt();
                                }else


                                if (kiemtra == 3) {

                                    kiemTraSoNgauNhien(CCCD);
                                    System.out.println("| 1. Kiem tra noi sinh ");
                                    System.out.println("| 2. Kiem tra tuoi, gioi tinh ");
                                    System.out.println("| 3. Kiem tra so ngau nhien ");
                                    System.out.println("| 0. Thoat ");
                                    System.out.println("chuc nang: ");
                                    kiemtra = sc.nextInt();
                                }
                                else {
                                    System.out.println("nhap lai de kiem tra: ");
                                    kiemtra = sc.nextInt();
                                }

                            } while (kiemtra != 0);

                        }else {
                            System.out.println("CCCD khong dung. Vui long thu lai:");
                        }

                    } else {
                        System.out.println("Ma xac thuc khong dung. Vui long thu lai:");
                    }

                } while (!maxacthuc.equals(ma));

            }
            if (luachon != 1 && luachon != 0) {
                System.out.println("Nhập lại:");
                luachon = sc.nextInt();
            }
            if (luachon == 0) {
                System.out.println("+-----------+--------------------------------+-----------+");
            }
        }
        while (luachon != 0);
    }

}

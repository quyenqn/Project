package asm03;

import asm02.Account;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public  class SavingsAccount extends Account implements ReportService, Withdraw {

    ArrayList<Transaction> transactions = new ArrayList<>();

    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }

    public void addTransactionHistory(String accountNumber, double amount) {
        Transaction newTransaction = new Transaction(accountNumber, amount);
        transactions.add(newTransaction);
    }

    public SavingsAccount(String accountNumber, double balance) {
        super(accountNumber, balance);
    }

    @Override
    public String toString() {
        Locale localeEN = new Locale("en", "EN");
        NumberFormat en = NumberFormat.getInstance(localeEN);
        return super.getAccountNumber() + " " + " | " + " Savings | " + en.format(super.getBalance());
    }

    public double getTransactionFee(){
        return 0.0;
    }

    @Override
    public void log(double amount) {

        System.out.println(Utils.getDivider());
        System.out.printf("%30s%n", "BIEN LAI GIAO DICH");
        System.out.printf("NGAY G/D: %28s%n", Utils.getDateTime());
        System.out.printf("ATM ID: %30s%n",  "DIGITAK-BANK-ATM 2002");
        System.out.printf("SO TK: %31s%n", getAccountNumber());
        System.out.printf("SO TIEN: %29s%n", Utils.formatBalance(amount) );
        System.out.printf("SO DU: %31s%n",Utils.formatBalance(getBalance()));
        System.out.printf("PHI: %27s%n", Utils.formatBalance(getTransactionFee() * amount));
        System.out.printf(Utils.getDivider());
    }

    @Override
    public boolean withdraw(double amount) {
        if (isAccepted(amount)){
            this.setBalance(getBalance()- amount);
            return true;
        }
        return false;
    }

    @Override
    public boolean isAccepted(double amount) {
        if (isPremium()){
            if (amount >= 50000 && amount < (getBalance() - 50000) && amount % 10000 == 0)
                return true;

        } else {
                if (amount >= 50000 && amount < (getBalance() - 50000) && amount % 10000 == 0 && amount <= 5000000 )
                    return true;
        }
        return false;
    }

    public void report() {
        for (Transaction tran : transactions) {
            System.out.println(tran.toString());
        }
    }

}

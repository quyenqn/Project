package asm03;

import asm02.Account;
import asm02.Customer;
import java.util.Scanner;

public class Asm03 {
    private static String CUSTOMER_ID = "001215000001";
    private static String CUSTOMER_NAME = "FUNIX";
    private static Scanner sc = new Scanner(System.in);
    private static  DigitalBank activeBank = new DigitalBank();
    private static void showCustomer(Customer customer){
        customer.displayInformation();
    }
    private static void withdraw(){
        try{
            System.out.println("nhap so tai khoan can rut tien: ");
                String account = sc.nextLine();
               if (account.isEmpty() || !activeBank.checkAccountExisted(CUSTOMER_ID,account)){
                System.out.println("so tai khoan khong duoc null hoac khong ton tai: ");
                return;
                }
                System.out.println("nhap so tien muon rut: ");
                double amount = Double.parseDouble(sc.nextLine());

                activeBank.withdraw(CUSTOMER_ID, account, amount);
        } catch (Exception ex){
            System.out.println("thong tin nhap vao khong hop le: ");
        }
    }

    public static void main(String[] args) {
        int luachon = 0;
        Customer customer  = new DigitalCustomer(CUSTOMER_NAME, CUSTOMER_ID);
        activeBank.addCustomer(customer);
        do {
            System.out.println("+-----------+--------------------------------+-----------+");
            System.out.println("| NGAN HANG SO | FX17743@V3.0.0                          |");
            System.out.println("+-----------+--------------------------------+-----------+");
            System.out.println("1. Thong tin khach hang ");
            System.out.println("2. Them tai khoan ATM ");
            System.out.println("3. Them tai khoan tin dung ");
            System.out.println("4. Rut tien ");
            System.out.println("5. Lich su giao dich ");
            System.out.println("0. Thoat ");
            System.out.println("+-----------+--------------------------------+-----------+");
            System.out.println("Chuc nang: ");
            luachon = sc.nextInt();
            sc.nextLine();
            if (luachon == 1){
                showCustomer(customer);
            } else if (luachon == 2) {
                System.out.println("nhap ma stk gom 6 so: ");
                String accountNumber = sc.nextLine();
                while (!(accountNumber.length() == 6 || Utils.isNumeric(accountNumber)) ||
                        activeBank.checkAccountExisted(CUSTOMER_ID,accountNumber)) {
                    System.out.println("nhap lai ma stk gom 6 so: ");
                    accountNumber = sc.nextLine();
                }
                System.out.println("nhap so du: ");
                //sc.nextLine();
                String balance = sc.nextLine();
                while (!Utils.isNumeric(balance) || Double.parseDouble(balance) < 50000) {
                    System.out.println("nhap lai so du: ");
                    balance = sc.nextLine();
                }
                Account acc = new SavingsAccount(accountNumber, Double.parseDouble(balance));
                activeBank.addAccount(CUSTOMER_ID,acc);
            } else if (luachon == 3) {
                System.out.println("nhap ma stk gom 6 so: ");
                String accountNumber = sc.nextLine();
                while (!(accountNumber.length() == 6 || Utils.isNumeric(accountNumber)) ||
                        activeBank.checkAccountExisted(CUSTOMER_ID,accountNumber)) {
                    System.out.println("nhap lai ma stk gom 6 so: ");
                    accountNumber = sc.nextLine();
                }
                System.out.println("nhap so du: ");
                //sc.nextLine();
                String balance = sc.nextLine();
                while (!Utils.isNumeric(balance) || Double.parseDouble(balance) < 50000 ) {
                    System.out.println("nhap lai so du: ");
                    balance = sc.nextLine();
                }
                Account acc = new LoansAccount(accountNumber, Double.parseDouble(balance));
                activeBank.addAccount(CUSTOMER_ID,acc);
            } else if (luachon == 4) {
                withdraw();
            } else if (luachon == 5) {
                activeBank.report(CUSTOMER_ID);
            }
        } while (luachon != 0);
    }

}

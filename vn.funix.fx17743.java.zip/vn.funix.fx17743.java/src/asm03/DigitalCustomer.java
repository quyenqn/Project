package asm03;

import asm02.Account;
import asm02.Customer;

import java.util.ArrayList;

public class DigitalCustomer extends Customer {

    public DigitalCustomer(String customerName, String customerId) {
        super(customerName, customerId);
    }

    public void withdraw(String accountNumber, double amount) {

        for (Account acc : getAccounts()) {
                if (accountNumber.equals(acc.getAccountNumber())){
                if (acc instanceof SavingsAccount){
                    SavingsAccount sa = (SavingsAccount) acc;
                    if (!sa.withdraw(amount))
                        return;
                        //sa.withdraw(amount);
                        sa.log(amount);
                        sa.addTransactionHistory(accountNumber,amount);

                }
                if (acc instanceof LoansAccount){
                    LoansAccount lo = (LoansAccount) acc;
                    if (!lo.withdraw(amount))
                        return;
                    //lo.withdraw(amount);
                    lo.log(amount);
                    lo.addTransactionHistory(accountNumber,amount);
                }
            break;
            }
        }
    }

    public void report() {
        displayInformation();
        for (Account account : getAccounts()) {
            if (account instanceof SavingsAccount) {
                ((SavingsAccount) account).report();
            }
            if (account instanceof LoansAccount) {
                ((LoansAccount) account).report();
            }
        }
    }

}


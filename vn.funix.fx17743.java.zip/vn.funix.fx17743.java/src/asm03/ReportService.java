package asm03;

public interface ReportService {
  void log(double amount);
}

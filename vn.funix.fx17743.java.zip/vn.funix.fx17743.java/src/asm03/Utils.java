package asm03;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Utils {

        public static String getDateTime() {
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date today = Calendar.getInstance().getTime();
            return df.format(today);
        }

        public static String getDivider() {
            return "----------------------------------------";
        }

        public static String getTitle() {
            return "NGAN HANG SO | FX17743@v3.0.0 |";
        }

        public static String formatBalance(double balance) {
            String formatBalance = "";
            String pattern = "###,###.###";
            DecimalFormat decimalFormat = new DecimalFormat(pattern);
            formatBalance = decimalFormat.format(balance);
            return formatBalance;
        }

    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            double d = Double.parseDouble(strNum);

        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;

    }


}




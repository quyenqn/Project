package asm03;
import asm02.Bank;
import asm02.Customer;

public class DigitalBank extends Bank {

    public void withdraw(String customerId, String accountNumber, double amount) {
        for (Customer cus : getCustomers()) {
            if (customerId.equals(cus.getCustomerId())) {
                DigitalCustomer digitalCustomer = (DigitalCustomer) cus;
                digitalCustomer.withdraw(accountNumber, amount);
                break;
            }
        }
    }

    public void report(String customerId) {
        for (Customer cus : getCustomers()) {
            if (customerId.equals(cus.getCustomerId())) {
                DigitalCustomer digitalCustomer = (DigitalCustomer) cus;
                digitalCustomer.report();
                break;
            }
        }
    }

}